build-release-or1420/src/grayscale_dma.c.o: src/grayscale_dma.c \
 support/include/stdio.h support/include/printf.h \
 support/include/ov7670.h support/include/stdint.h support/include/swap.h \
 support/include/defs.h support/include/vga.h
