build-release-or1420/src/relu.c.o: src/relu.c support/include/stdio.h \
 support/include/printf.h support/include/swap.h support/include/defs.h \
 support/include/stdint.h
