build-release-or1420/src/dma2.c.o: src/dma2.c support/include/stdint.h \
 support/include/stdio.h support/include/printf.h support/include/swap.h \
 support/include/defs.h
