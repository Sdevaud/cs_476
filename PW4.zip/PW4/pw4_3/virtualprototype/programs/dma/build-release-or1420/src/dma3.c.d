build-release-or1420/src/dma3.c.o: src/dma3.c support/include/stdint.h \
 support/include/stdio.h support/include/printf.h support/include/swap.h \
 support/include/defs.h
