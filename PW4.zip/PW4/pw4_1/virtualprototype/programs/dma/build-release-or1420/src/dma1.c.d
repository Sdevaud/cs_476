build-release-or1420/src/dma1.c.o: src/dma1.c support/include/stdint.h \
 support/include/stdio.h support/include/printf.h
